package com.example.aggregation.controller;

import com.example.aggregation.model.AggregationResponse;
import com.example.aggregation.service.AggregationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/aggregation-demo")
public class AggregationController {

    @Autowired
    AggregationService aggregationService;

    @GetMapping(value = "{customer-id}/aggregation")
    public ResponseEntity<AggregationResponse> getAggregation(@PathVariable("customer-id") String customerId) {
        return ResponseEntity.status(HttpStatus.OK).body(aggregationService.getAggregation(customerId));
    }

}
