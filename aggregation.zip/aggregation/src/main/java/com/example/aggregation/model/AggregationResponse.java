package com.example.aggregation.model;

import lombok.Builder;
import lombok.Value;

import java.util.List;

@Builder
@Value
public class AggregationResponse {
    private String id;
    private List<Order> orders;

}
