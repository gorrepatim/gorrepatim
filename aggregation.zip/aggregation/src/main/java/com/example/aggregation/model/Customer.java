package com.example.aggregation.model;

import lombok.Builder;
import lombok.Value;

import java.util.List;


@Builder
@Value
public class Customer {
     String id;
     List<Integer> order_id;

}
