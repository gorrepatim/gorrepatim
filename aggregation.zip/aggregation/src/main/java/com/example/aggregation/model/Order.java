package com.example.aggregation.model;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class Order {
    private Integer id;
    private double order_total;
    private String purchased_at;
    private String order_crated_date;
    private OrderLines order_lines;

}
