package com.example.aggregation.model;

import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class OrderLines {
     String item_id;
     String item_description;
     int item_qty;
     double item_price;
}
