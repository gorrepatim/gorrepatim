package com.example.aggregation.service;

import com.example.aggregation.model.AggregationResponse;
import com.example.aggregation.model.Customer;
import com.example.aggregation.model.Order;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AggregationService {

    WebclientConnector connector;

    public AggregationResponse getAggregation(String customerId) {
        Customer customer = connector.getCustomer(customerId);
        List<Order> orderList = connector.getOrders();
        return filterOrderList(customer, orderList);

    }

    private AggregationResponse filterOrderList(Customer customer, List<Order> orderList) {
        List<Order> orders = new ArrayList<>();
          for(Order order : orderList) {
              customer.getOrder_id().contains(order.getId());
              orders.add(order);
          }
          return AggregationResponse.builder().id(customer.getId()).orders(orders).build();

    }
}
