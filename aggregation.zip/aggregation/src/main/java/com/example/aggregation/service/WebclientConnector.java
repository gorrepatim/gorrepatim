package com.example.aggregation.service;

import com.example.aggregation.model.Customer;
import com.example.aggregation.model.Order;
import com.sun.xml.internal.ws.handler.HandlerException;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.List;

public class WebclientConnector {

    WebClient connector;

    @PostConstruct
    public void setUpClient() {
        connector = WebClient.builder().baseUrl("http://my-json-server.typicode.com/pfconrey/json-server/").build();
    }

    public Customer getCustomer(String customerId) {
        return connector
                .get()
                .uri("customers", customerId)
                .retrieve()
                .onStatus(HttpStatus::is2xxSuccessful, clientResponse -> Mono.empty())
                .onStatus(HttpStatus::isError,
                        clientResponse -> {
                    return Mono.error(() ->new HandlerException("Error", clientResponse.statusCode()));
                        }).bodyToFlux(Customer.class).blockFirst();

    }

    public List<Order> getOrders() {
        return connector
                .get()
                .uri("orders")
                .retrieve()
                .onStatus(HttpStatus::is2xxSuccessful, clientResponse -> Mono.empty())
                .onStatus(HttpStatus::isError,
                        clientResponse -> {
                            return Mono.error(() ->new HandlerException("Error", clientResponse.statusCode()));
                        }).bodyToFlux(Order.class)
                        .collectList()
                        .block();

    }
}
